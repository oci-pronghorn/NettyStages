'use strict';

angular.module('myApp.services', []).value('version', '0.1');

var app = angular.module('myApp');

app.value('data',[  ]);
